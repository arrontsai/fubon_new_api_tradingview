from ..client import WebSocketClient

class WebSocketStockClient(WebSocketClient):
    pass