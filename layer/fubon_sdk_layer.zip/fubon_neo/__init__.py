from fubon_neo._fubon_neo import version

__version__ = version()
