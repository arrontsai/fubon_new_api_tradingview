from enum import Enum, auto

class Mode(Enum):
    Normal = auto()
    Speed = auto()
